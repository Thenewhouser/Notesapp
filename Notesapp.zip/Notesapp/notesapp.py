import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from PIL import Image, ImageDraw, ImageTk
import os

# Ensure the notesapp folder exists
if not os.path.exists('notesapp'):
    os.makedirs('notesapp')

# Setup the main window
root = tk.Tk()
root.title("NotesApp")

# Text Note Functions
def save_note():
    note_title = simpledialog.askstring("Input", "Enter the note title:")
    if not note_title:
        messagebox.showwarning("Save Note", "Note title is required!")
        return
    note_content = note_text.get("1.0", tk.END).strip()
    if not note_content:
        messagebox.showwarning("Save Note", "No content to save!")
        return
    with open(f'notesapp/{note_title}.txt', 'w') as file:
        file.write(note_content)
    note_list.append(note_title)
    note_menu['menu'].add_command(label=note_title, command=tk._setit(selected_note, note_title))
    messagebox.showinfo("Save Note", "Note saved successfully!")

def load_note():
    title = selected_note.get()
    if not title:
        messagebox.showwarning("Load Note", "No note selected!")
        return
    try:
        with open(f'notesapp/{title}.txt', 'r') as file:
            note_content = file.read()
        note_text.delete("1.0", tk.END)
        note_text.insert(tk.END, note_content)
    except FileNotFoundError:
        messagebox.showerror("Load Note", "Note file not found!")

def delete_note():
    title = selected_note.get()
    if not title:
        messagebox.showwarning("Delete Note", "No note selected!")
        return
    os.remove(f'notesapp/{title}.txt')
    note_list.remove(title)
    note_menu['menu'].delete(note_menu['menu'].index(title))
    selected_note.set('')
    note_text.delete("1.0", tk.END)
    messagebox.showinfo("Delete Note", "Note deleted successfully!")

# Drawing Canvas Functions
def save_drawing():
    global image
    file_path = filedialog.asksaveasfilename(defaultextension=".png", filetypes=[("PNG files", "*.png")])
    if file_path:
        image.save(file_path)
        messagebox.showinfo("Save Drawing", "Drawing saved successfully!")

def clear_drawing():
    global draw
    canvas.delete("all")
    draw.rectangle([(0, 0), (400, 400)], fill="white")
    canvas_image = ImageTk.PhotoImage(image)
    canvas.create_image(0, 0, anchor=tk.NW, image=canvas_image)
    canvas.image = canvas_image

def on_draw(event):
    x, y = event.x, event.y
    draw.line([(x-1, y-1), (x+1, y+1)], fill="black", width=2)
    draw.line([(x-1, y+1), (x+1, y-1)], fill="black", width=2)
    canvas.create_line(event.x, event.y, event.x+1, event.y+1, fill="black", width=2)

# Create and configure the text note area
note_text = tk.Text(root, width=60, height=10)
note_text.pack(pady=10)

note_list = [f.split('.')[0] for f in os.listdir('notesapp') if f.endswith('.txt')]
selected_note = tk.StringVar(root)

# Dropdown menu to select notes
note_menu = tk.OptionMenu(root, selected_note, *note_list)
note_menu.pack(pady=10)

save_note_btn = tk.Button(root, text="Save Note", command=save_note)
save_note_btn.pack(side=tk.LEFT, padx=10)

load_note_btn = tk.Button(root, text="Load Note", command=load_note)
load_note_btn.pack(side=tk.LEFT, padx=10)

delete_note_btn = tk.Button(root, text="Delete Note", command=delete_note)
delete_note_btn.pack(side=tk.LEFT, padx=10)

# Create and configure the drawing canvas
canvas = tk.Canvas(root, width=400, height=400, bg="white")
canvas.pack(pady=10)

canvas.bind("<B1-Motion>", on_draw)

# Initialize the image and drawing tools
image = Image.new("RGB", (400, 400), "white")
draw = ImageDraw.Draw(image)
canvas_image = ImageTk.PhotoImage(image)
canvas.create_image(0, 0, anchor=tk.NW, image=canvas_image)
canvas.image = canvas_image

save_drawing_btn = tk.Button(root, text="Save Drawing", command=save_drawing)
save_drawing_btn.pack(side=tk.LEFT, padx=10)

clear_drawing_btn = tk.Button(root, text="Clear Drawing", command=clear_drawing)
clear_drawing_btn.pack(side=tk.LEFT, padx=10)

# Run the application
root.mainloop()
